/* -- LISTA de constantes usadas em APIs -- */

// Exemplo
const String tSecretAPIKey = "cwt_live_b2da6ds3df3e785v8ddc59198f7615ba";