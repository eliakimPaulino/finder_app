/* --
      LISTA DE Enums
      Eles não podem ser criados dentro de uma classe.
-- */

/// Alternância do Widget Custom Brand-Text-Size
enum TextSizes { small, medium, large }

enum OrderStatus { processing, shipped, delivered }

enum PaymentMethods { paypal, googlePay, applePay, visa, masterCard, creditCard, paystack, razorPay, paytm }

