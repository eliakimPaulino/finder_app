class KImages {

  // -- App Logos
  static const String darkAppLogo = 'assets/logos/dark_finder_app_icon.png';
  static const String lightAppLogo = 'assets/logos/light_finder_app_icon.png';

  // -- App Icons

  // -- App Backgrounds

  // -- App Illustrations

  // -- App Avatars

  // -- App Animations

  // -- App Videos

  // -- App Sounds

  // -- App Fonts

}