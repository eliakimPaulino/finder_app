import '../../domain/entities/item_entity.dart';

class ComponentModel extends ComponentEntity {
  const ComponentModel({
    required super.item,
    required super.descricao,
    required super.area,
    required super.localReferencia,
    required super.prateleira,
    required super.posicao,
    required super.projeto,
    required super.sigla,
    required super.montagem,
    required super.fluxo,
  });

  factory ComponentModel.fromJson(Map<String, dynamic> json) {
    return ComponentModel(
      item: json['item'] ?? '',
      descricao: json['description'] ?? '',
      area: json['area'] ?? '',
      localReferencia: json['local_referencia'] ?? '',
      prateleira: json['prateleira'] ?? '',
      posicao: json['posicao'] ?? '',
      projeto: json['projeto'] ?? '',
      sigla: json['sigla'] ?? '',
      montagem: json['montagem'] ?? '',
      fluxo: json['fluxo'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'item': item,
      'description': descricao,
      'area': area,
      'local_referencia': localReferencia,
      'prateleira': prateleira,
      'posicao': posicao,
      'projeto': projeto,
      'sigla': sigla,
      'montagem': montagem,
      'fluxo': fluxo,
    };
  }
}
